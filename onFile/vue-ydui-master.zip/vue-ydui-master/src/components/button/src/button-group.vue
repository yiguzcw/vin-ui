<template>
    <div class="yd-button"><slot></slot></div>
</template>

<script type="text/babel">
    export default {
        name: 'yd-button-group'
    }
</script>
