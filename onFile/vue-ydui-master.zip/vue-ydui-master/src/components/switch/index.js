import Switch from './src/switch.vue';
export {Switch};
