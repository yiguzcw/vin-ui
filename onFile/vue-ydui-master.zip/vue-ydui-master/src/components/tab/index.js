import Tab from './src/tab.vue';
import TabPanel from './src/tab-panel.vue';

export {Tab, TabPanel};
