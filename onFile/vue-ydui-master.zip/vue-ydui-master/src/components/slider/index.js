import Slider from './src/slider.vue';
import SliderItem from './src/slider-item.vue';

export {Slider, SliderItem};
