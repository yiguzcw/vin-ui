import BackTop from './src/backtop.vue';
export {BackTop};
