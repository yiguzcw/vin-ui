import TabBar from './src/tabbar.vue';
import TabBarItem from './src/tabbar-item.vue';
import TabBarOther from './src/tabbar-other.vue';

export {TabBar, TabBarItem, TabBarOther};
