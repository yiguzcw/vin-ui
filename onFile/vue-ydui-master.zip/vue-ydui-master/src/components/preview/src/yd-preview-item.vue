<template>
    <div class="yd-preview-item">
        <slot name="left"></slot>
        <slot name="right"></slot>
    </div>
</template>

<script type="text/babel">
    export default {
        name: 'yd-preview-item'
    }
</script>
