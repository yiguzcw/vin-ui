<template>
    <div class="yd-preview-header">
        <slot name="left"></slot>
        <slot name="right"></slot>
    </div>
</template>

<script type="text/babel">
    export default {
        name: 'yd-preview-header'
    }
</script>
