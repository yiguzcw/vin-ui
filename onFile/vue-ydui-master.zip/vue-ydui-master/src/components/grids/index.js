import GridsItem from './src/grids-item.vue';
import GridsGroup from './src/grids-group.vue';

export {GridsItem, GridsGroup};
