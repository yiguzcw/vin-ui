import Rate from './src/rate.vue';
export {Rate};
