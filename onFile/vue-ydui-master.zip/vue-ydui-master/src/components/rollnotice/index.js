import RollNotice from './src/rollnotice.vue';
import RollNoticeItem from './src/rollnotice-item.vue';
export {RollNotice, RollNoticeItem};
