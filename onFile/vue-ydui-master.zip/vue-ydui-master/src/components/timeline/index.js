import TimeLine from './src/timeline.vue';
import TimeLineItem from './src/timeline-item.vue';
export {TimeLine, TimeLineItem};
