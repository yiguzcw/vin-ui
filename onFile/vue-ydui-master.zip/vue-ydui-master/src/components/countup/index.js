import CountUp from './src/countup.vue';
export {CountUp};
