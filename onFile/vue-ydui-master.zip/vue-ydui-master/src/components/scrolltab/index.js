import ScrollTab from './src/scrolltab.vue';
import ScrollTabPanel from './src/scrolltab-panel.vue';

export {ScrollTab, ScrollTabPanel};
