import Icons from './src/icons.vue';
export {Icons};
