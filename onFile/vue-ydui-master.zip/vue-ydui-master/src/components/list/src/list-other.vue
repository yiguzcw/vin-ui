<template>
    <div class="yd-list-other">
        <slot></slot>
    </div>
</template>

<script type="text/babel">
    export default {
        name: 'yd-list-other'
    }
</script>
