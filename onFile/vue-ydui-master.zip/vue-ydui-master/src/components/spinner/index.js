import Spinner from './src/spinner.vue';
export {Spinner};
