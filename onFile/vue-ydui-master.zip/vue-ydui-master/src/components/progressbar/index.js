import ProgressBar from './src/progressbar.vue';
export {ProgressBar};
