import ScrollNav from './src/scrollnav.vue';
import ScrollNavPanel from './src/scrollnav-panel.vue';

export {ScrollNav, ScrollNavPanel};
