import CountDown from './src/countdown.vue';
export {CountDown};
