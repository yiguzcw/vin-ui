import SendCode from './src/sendcode.vue';
export {SendCode};
