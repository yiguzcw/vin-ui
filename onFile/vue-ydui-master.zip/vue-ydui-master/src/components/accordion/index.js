import Accordion from './src/accordion.vue';
import AccordionItem from './src/accordion-item.vue';
export {Accordion, AccordionItem};
