import Search from './src/search.vue';
export {Search};
