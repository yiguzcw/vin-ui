import LightBox from './src/lightbox.vue';
import LightBoxImg from './src/lightbox-img.vue';
import LightBoxTxt from './src/lightbox-txt.vue';
export {LightBox, LightBoxImg, LightBoxTxt};
