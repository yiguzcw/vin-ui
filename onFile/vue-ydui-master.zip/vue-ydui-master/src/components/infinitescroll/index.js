import InfiniteScroll from './src/infinitescroll.vue';
export {InfiniteScroll};
