<template>
    <router-view></router-view>
</template>

<style lang="less">
    @import "./styles/demo.less";
    @import "../src/styles/base.less";
</style>
