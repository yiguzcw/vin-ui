<template>
    <yd-layout title="C&R">
        <yd-cell-group class="demo-small-pitch">
            <yd-cell-item arrow type="link" href="/switch">
                <span slot="left">Switch</span>
            </yd-cell-item>
            <yd-cell-item arrow type="link" href="/radio">
                <span slot="left">Radio</span>
            </yd-cell-item>
            <yd-cell-item arrow type="link" href="/checkbox">
                <span slot="left">CheckBox</span>
            </yd-cell-item>
        </yd-cell-group>

    </yd-layout>
</template>
