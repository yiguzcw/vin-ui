<template>
    <yd-layout title="AsideBar">

        <yd-cell-group class="demo-small-pitch">
            <yd-cell-item arrow type="link" href="/navbar">
                <span slot="left">NavBar</span>
            </yd-cell-item>
            <yd-cell-item arrow type="link" href="/tabbar">
                <span slot="left">TabBar</span>
            </yd-cell-item>
        </yd-cell-group>

    </yd-layout>
</template>
