<template>
    <yd-layout title="TimeLine">
        <yd-timeline class="demo-small-pitch">
            <yd-timeline-item>
                <p>【南宁市】您的订单正在配送途中，请您准备签收，感谢您的耐心等待。京东扫码付，单单享立减。</p>
                <p style="margin-top: 10px;">2017-08-18 08:24:18</p>
            </yd-timeline-item>
            <yd-timeline-item>
                <p>【南宁市】您的订单已到达【南宁安吉站】</p>
                <p style="margin-top: 10px;">2017-08-18 07:25:08</p>
            </yd-timeline-item>
            <yd-timeline-item>
                <p>【南宁市】您的订单在京东【南宁分拨中心】发货完成，准备送往京东【南宁安吉站】</p>
                <p style="margin-top: 10px;">2017-08-17 21:44:08</p>
            </yd-timeline-item>
            <yd-timeline-item>
                <p>【南宁市】您的订单在京东【南宁分拨中心】分拣完成</p>
                <p style="margin-top: 10px;">2017-08-17 21:43:38</p>
            </yd-timeline-item>
            <yd-timeline-item>
                <p>您的订单已经进入京东2号库准备出库</p>
                <p style="margin-top: 10px;">2017-08-17 19:40:42</p>
            </yd-timeline-item>
            <yd-timeline-item>
                <p>您提交了订单，请等待系统确认</p>
                <p style="margin-top: 10px;">2017-08-17 19:40:07</p>
            </yd-timeline-item>
        </yd-timeline>
    </yd-layout>
</template>
