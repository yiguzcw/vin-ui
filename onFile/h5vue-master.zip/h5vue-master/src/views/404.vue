<template>
  <div>
    404
    <router-link replace to="/">返回首页</router-link>
  </div>
</template>
<script>
export default {
  name: 'page404'
}
</script>
