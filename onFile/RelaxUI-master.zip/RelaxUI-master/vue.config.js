module.exports = {
  devServer: {
    port: 1024, // 端口
  },
  productionSourceMap: false,
  publicPath: './',
  outputDir: './docs',
  runtimeCompiler: true,
  lintOnSave: false
}