import Element from './datepicker'

Element.install = function (Vue) {
  Vue.component(Element.name, Element)
}

export default Element
