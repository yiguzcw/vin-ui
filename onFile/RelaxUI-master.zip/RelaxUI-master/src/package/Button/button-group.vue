<script>
export default {
  name: 'xButtonGroup',
  render () {
    return <div class='x-btn-group'>{this.$slots.default}</div>
  }
}
</script>
