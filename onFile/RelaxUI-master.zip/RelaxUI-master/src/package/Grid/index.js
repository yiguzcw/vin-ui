import {
  install
} from '../utils/install'

import Col from './col'
import Row from './row'

export default install({
  Col,
  Row
})
