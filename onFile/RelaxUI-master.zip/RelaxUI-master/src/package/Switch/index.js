import Element from './switch.vue'

Element.install = function (Vue) {
  Vue.component(Element.name, Element)
}

export default Element
