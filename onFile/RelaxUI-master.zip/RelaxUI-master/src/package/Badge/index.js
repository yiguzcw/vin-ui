import Element from './badge'

Element.install = function (Vue) {
  Vue.component(Element.name, Element)
}

export default Element
