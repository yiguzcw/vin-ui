<template>
  <div class="index">
    <div class="content">
      <div>
        <img src="@/docs/assets/logo.png" alt>
      </div>
      <div class="logo-title">Relax UI</div>
      <p class="logo-description">基于 VUE 打造的平民组件库</p>
      <div class="github">
        <iframe src="https://ghbtns.com/github-btn.html?user=yanghuanrong&amp;repo=RelaxUI&amp;type=watch&amp;count=true&amp;v=2" frameborder="0" scrolling="0" width="100px" height="20px"></iframe>
        <iframe src="https://ghbtns.com/github-btn.html?user=yanghuanrong&amp;repo=RelaxUI&amp;type=star&amp;count=true" frameborder="0" scrolling="0" width="100px" height="20px"></iframe>
        <iframe src="https://ghbtns.com/github-btn.html?user=yanghuanrong&amp;repo=RelaxUI&amp;type=fork&amp;count=true" frameborder="0" scrolling="0" width="100px" height="20px"></iframe>
      </div>
      <div>
        <router-link to="/button">
          <x-button type='primary' size="lg" round>开始使用</x-button>
        </router-link>
      </div>
    </div>
    <div class="element">
      <div class="element1"></div>
      <div class="element2"></div>
      <div class="element3"></div>
      <div class="element4"></div>
      <div class="element5"></div>
      <div class="element6"></div>
      <div class="element7"></div>
      <div class="element8"></div>
      <div class="element9"></div>
      <div class="element10"></div>
      <div class="element11"></div>
      <div class="element12"></div>
      <div class="element13"></div>
    </div>
  </div>
</template>