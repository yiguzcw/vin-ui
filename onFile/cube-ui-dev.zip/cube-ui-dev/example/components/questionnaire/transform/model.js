export default function transformModel(config, field) {
  field.modelKey = config.model
  field.key = config.model
}
