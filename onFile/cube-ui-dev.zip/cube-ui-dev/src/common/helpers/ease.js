export const easeOutBack = 'cubic-bezier(0.18, 0.89, 0.32, 1.28)'
export const easeOutQuart = 'cubic-bezier(0.165, 0.84, 0.44, 1)'
export const easeOutCubic = 'cubic-bezier(0.22, 0.61, 0.36, 1)'
