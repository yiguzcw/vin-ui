## 版本发布

<p class="tip">
`0.x` 版本文档不完整，并且已经不再维护。请更新或者直接使用`2.x`。
</p>

当前开发分支为 [v2](https://github.com/airyland/vux)。

`2.1.0` ~ `3.0.0` 之间版本不会有影响升级的 `break change`，请放心及时更新版本。
