---
title: VUX 服务端渲染
---

# VUX 服务端渲染

目前支持 `NUXT` 渲染，可以参考例子：[https://github.com/nuxt/nuxt.js/tree/dev/examples/with-vux](https://github.com/nuxt/nuxt.js/tree/dev/examples/with-vux)。
