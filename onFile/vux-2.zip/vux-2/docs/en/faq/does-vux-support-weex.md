---
title: Does VUX support weex
---

# Does VUX support weex

No, and not plan to support it.