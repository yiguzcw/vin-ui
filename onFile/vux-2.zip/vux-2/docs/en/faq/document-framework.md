---
title: 文档是用什么工具编写的？
---

# 文档是用什么工具编写的？

早期版本使用的是 [Docute](https://docute.js.org) by [egoist](https://github.com/egoist)。在`Docute`基础上做了一点样式修改。

2.2.1 后面版本出于 `SEO` 考虑使用 `Vue` 的服务端渲染，使用的框架同样是 [egoist](https://github.com/egoist) 开发的 [ream](https://github.com/ream/ream)。

文档部分样式参照了 [eggjs.org](https://eggjs.org/)，表示感谢。

因此目前无论是组件还是文档都是完全基于 `Vue`，cool right?