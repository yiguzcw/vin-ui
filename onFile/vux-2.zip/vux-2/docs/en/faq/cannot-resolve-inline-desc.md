---
title: Can't resolve '../inline-desc' in
--- 

# Can't resolve '../inline-desc' in

webpack resolve 配置

``` js
resolve: {
  extensions: ['', '.js', '.vue', '.json']
}
```