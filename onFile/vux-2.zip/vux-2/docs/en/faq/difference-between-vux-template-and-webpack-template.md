---
title: vux2 和 Vue 官方 webpack 模板区别是什么？
---

# vux2 和 Vue 官方 webpack 模板区别是什么？

`vux2` 模板 fork 自 `webpack` 模板并进行了配置，和 `webpack` 模板基本同步，因此建议直接使用 vux2 模板。