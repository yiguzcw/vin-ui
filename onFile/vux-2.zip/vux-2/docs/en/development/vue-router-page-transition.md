---
title: 页面切换转场动画
---

# 页面切换转场动画

你可以注意到 demo 站点的切换动画，本质上是使用 `Vue` 的 `transition` 组件实现的。

- [ ] todo