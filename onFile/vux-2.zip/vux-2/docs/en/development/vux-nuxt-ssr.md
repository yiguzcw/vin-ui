---
title: vux 使用 nuxt 实现服务端渲染
---

# vux 使用 nuxt 实现服务端渲染

请直接参考源码目录 [/ssr/nuxt](https://github.com/airyland/vux/tree/v2/ssr/nuxt)
