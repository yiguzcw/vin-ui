---
title: vue-router 路由
---

# 路由

推荐直接使用官方 [vue-router](https://github.com/vuejs/vue-router)，`VUX`部分组件支持`link`属性直接支持`vue-router`的路由参数，`vux2`模板内置了`vue-router`。

::: warning
<del>如果使用了过渡(转场动画)，在`iPhone`上使用`左划返回`时动画会再执行一遍，目前没有找到可行的处理方法，如果你有处理方案，欢迎`PR`。</del>
[https://github.com/airyland/vux/pull/2259](https://github.com/airyland/vux/pull/2259)
:::
