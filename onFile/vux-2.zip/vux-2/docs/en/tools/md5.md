---
title: md5
---

# md5

::: tip
该工具直接依赖于 [blueimp-md5](https://github.com/blueimp/JavaScript-MD5)

注意: `md5`是消息摘要算法并非加密算法，用于需要加密的场景会有安全问题。
:::

``` js
import { md5 } from 'vux'

md5('VUX')
```
