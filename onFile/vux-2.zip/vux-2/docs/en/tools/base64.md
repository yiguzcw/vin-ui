---
title: base64
---

# base64

``` js
import { base64 } from 'vux'

base64.encode('VUX')
base64.decode('VlVY')
```