---
title: Vue trim string
---

# trim string

``` js
import { trim } from 'vux'

trim(' 1024 ') // 1024
```
