---
title: 捐赠支持 VUX
---


## 捐赠

* [Patreon](https://www.patreon.com/airyland)
* [PayPal](https://paypal.me/airyland)
* 支付宝 airyland@qq.com
