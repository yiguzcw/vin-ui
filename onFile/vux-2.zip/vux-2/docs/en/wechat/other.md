---
title: 其他问题
---

## 如何实现`weui.io`或者星巴克页面的设置顶部bar和页面下拉背景色

微信对于部分合作方开放了`jssdk`的`setBounceBackground`及`setNavigationBarColor`权限，目测暂无申请入口。