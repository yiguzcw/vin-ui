---
title: 捐赠支持 VUX
---

## 感谢赞助商

<br>
<p class="best-companies">
  <a href="https://www.bmqb.com/a/jobs?tracking_code=opencollective" target="_blank">
    <img src="https://ww1.sinaimg.cn/large/663d3650gy1fs3l6w13z2j206y02bdfp.jpg"/>
  </a>
  <a href="https://www.upyun.com" target="_blank">
    <img src="https://ww1.sinaimg.cn/large/663d3650gy1fs3l83hokej20b4040weg.jpg" style="height:52px;"/>
  </a>
  <br>
  <a href="https://www.sb/?utm_source=vux">
    <img src="http://wx1.sinaimg.cn/mw690/0060lm7Tly1ftmvim3r34j3056034wee.jpg">
  </a>
</p>

<br>

## 感谢捐赠用户

> 即将上线，捐赠时的附加信息也将显示在这里。

<br>

## 捐赠方式

> 欢迎通过下面渠道进行捐赠

* [Patreon](https://www.patreon.com/airyland)
* [Open Collective](https://opencollective.com/vux)
* [PayPal](https://paypal.me/airyland)
* 支付宝 airyland@qq.com
* 企业赞助捐赠请联系 i@mao.li
