---
title: Vue string 工具函数
---

# string 处理工具

``` js
import { trim } from 'vux'

trim(' 1024 ') // 1024
```
