---
title: VUX 是否支持 weex
---

# VUX 是否支持 weex

不支持，也没有计划支持。