---
title: VUX 使用案例
---

# 使用案例

> 如果你的产品在使用`VUX`, 请直接发 PR 修改 `docs/zh-CN/about/showcase.md`（置于列表最后，统一格式：二维码必须无白边框）。

<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwihri9hzj2066066dgb.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwii8udl7j2088088jrj.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwiiq61ihj207v07vjr8.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwij2qezej2066066dfy.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwijfw73zj20aa0aaaa9.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwijtrvp1j20do0do4gp.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwike27c8j207c07cdg4.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwikqk1xwj2088088myl.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwil30l2oj20b40b4wf0.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwilfmz9xj20aa0aaacp.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwilte2naj20aa0aajru.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwim77oc5j2064066gnh.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpwimm8dtkj208508cqjf.jpg" width="150">
<img src="https://ws1.sinaimg.cn/large/663d3650gy1fpmuvjf5x6j208c08c74f.jpg" width="150">
<img src="https://common-1251785959.cosbj.myqcloud.com/mdachu.jpg" width="150">
<img src="https://img.yw0511.com/others/1528080310.png" width="150" alt="原味生活">
<img src="http://images.wumakeji.com/niuxiaoyun/1528080310.jpg" width="150" alt="牛小云">
