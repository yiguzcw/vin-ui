<template>
  <div>
    <on feature="FEATURE1">
      ON FEATURE1
    </on>
    <off feature="FEATURE1">
      OFF FEATURE1
    </off>
    <on feature="FEATURE2">
      ON FEATURE2
    </on>
    <off feature="FEATURE2">
      OFF FEATURE2
    </off>
  </div>
</template>

<script>
export default {
}
</script>
