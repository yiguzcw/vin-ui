<template>
  <p>{{msg}}</p>
</template>

<script>
export default {
  data () {
    return {
      msg: 'AAAA'
    }
  }
}
</script>

<style>
comp-a h2 {
  color: #f00;
}
</style>
