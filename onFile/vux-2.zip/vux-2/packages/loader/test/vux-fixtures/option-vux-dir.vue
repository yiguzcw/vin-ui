<template>
  <div>
    <group>
      <cell title="hello"></cell>
    </group>
  </div>
</template>

<script>
import Group from '../../node_modules/vux/src/components/group/index.vue'

export default {
  components: {
    Group,
    Cell
  }
}
</script>