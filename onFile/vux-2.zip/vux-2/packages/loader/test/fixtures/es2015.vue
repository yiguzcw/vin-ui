<template>
  <div :class="{ [`test-${a}`]: true, b }"></div>
</template>
