<style scoped>
@media print {
  .foo {
    color: #000;
  }
}
</style>
