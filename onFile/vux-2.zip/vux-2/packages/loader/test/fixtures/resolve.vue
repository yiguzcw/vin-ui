<template>
<div>
  <img src="./logo.png">
  <img src="~fixtures/logo.png">
</div>
</template>

<style>
html { background-image: url(./logo.png); }
body { background-image: url(~fixtures/logo.png); }
</style>
