<style lang="stylus">
h1
  color red
</style>

<style>
h2 {
  color: green;
}
</style>
