<style>
h1
  color: red
  font-size: 14px
</style>
