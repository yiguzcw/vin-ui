window.injector = require('!!../../lib/loader?inject!./inject.vue')
