<style module="style">
.red {
  color: red;
}
@keyframes fade {
  from { opacity: 1; } to { opacity: 0; }
}
.animate {
  animation: fade 1s;
}
</style>

<style scoped lang="stylus" module>
.red
  color: red
</style>

<script>
module.exports = {}
</script>
