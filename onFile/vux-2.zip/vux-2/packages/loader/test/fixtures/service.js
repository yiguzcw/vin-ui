module.exports = {
  msg: 'hi'
}
