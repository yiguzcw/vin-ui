<style src="./style-import.css"></style>
<style src="./style-import-scoped.css" scoped></style>
