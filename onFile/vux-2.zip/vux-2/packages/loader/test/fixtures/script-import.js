export default {
  data () {
    return {
      msg: 'Hello from Component A!'
    }
  }
};