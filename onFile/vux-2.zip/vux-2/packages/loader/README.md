# vux-loader

A webpack loader for processing .vue file before vue-loader