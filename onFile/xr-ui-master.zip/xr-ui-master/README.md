# xr-ui
基于 vue-cli3 的 UI 组件库

### Install
```
npm install xr-ui -S
```

### Usage
```
import Vue from "vue"
import XrUI from 'xr-ui'
import 'xr-ui/lib/xr-ui.css'

Vue.use(XrUI)
```
在项目中使用
```
<xr-test></xr-test>
```