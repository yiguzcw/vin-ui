<template>
  <div>
    <!-- 卧槽这是个坑比点 -->
    <xr-test></xr-test>
  </div>
</template>

<script>
export default {
  name: 'home'
}
</script>
